﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cake_Shop_Management_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            radioButton1.ForeColor = System.Drawing.Color.Green;
            radioButton2.ForeColor = System.Drawing.Color.Black;
            radioButton3.ForeColor = System.Drawing.Color.Black;


            cmb_items.Items.Clear();
            cmb_items.Items.Add("Chocolate Sponge Cake");
            cmb_items.Items.Add("Red Velvet Cake");
            cmb_items.Items.Add("White Chocolate Vanila Cake");

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            radioButton2.ForeColor = System.Drawing.Color.Green;
            radioButton1.ForeColor = System.Drawing.Color.Black;
            radioButton3.ForeColor = System.Drawing.Color.Black;


            cmb_items.Items.Clear();
            cmb_items.Items.Add("Peanut Butter Fudge Cupcake");
            cmb_items.Items.Add("Triple Chocolate Cupcake");
            cmb_items.Items.Add("Marble Cupcake");

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            radioButton3.ForeColor = System.Drawing.Color.Green;
            radioButton2.ForeColor = System.Drawing.Color.Black;
            radioButton1.ForeColor = System.Drawing.Color.Black;


            cmb_items.Items.Clear();
            cmb_items.Items.Add("Strawbarry Butterscotch icecream");
            cmb_items.Items.Add("Mixed icecream");
            cmb_items.Items.Add("Chocolate Milkshake with caramel");

        }

        private void cmb_items_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmb_items.SelectedItem.ToString() == "Chocolate Sponge Cake")
            { txt_price.Text = "750"; }
            else if (cmb_items.SelectedItem.ToString() == "Red Velvet Cake")
            { txt_price.Text = "650"; }
            else if (cmb_items.SelectedItem.ToString() == "White Chocolate Vanila Cake")
            { txt_price.Text = "700"; }
            else if (cmb_items.SelectedItem.ToString() == "Peanut Butter Fudge Cupcake")
            { txt_price.Text = "120"; }
            else if (cmb_items.SelectedItem.ToString() == "Triple Chocolate Cupcake")
            { txt_price.Text = "100"; }
            else if (cmb_items.SelectedItem.ToString() == "Marble Cupcake")
            { txt_price.Text = "100"; }
            else if (cmb_items.SelectedItem.ToString() == "Strawbarry Butterscotch icecream")
            { txt_price.Text = "120"; }
            else if (cmb_items.SelectedItem.ToString() == "Mixed icecream")
            { txt_price.Text = "150"; }
            else if (cmb_items.SelectedItem.ToString() == "Chocolate Milkshake with caramel")
            { txt_price.Text = "100"; }
            else
            { txt_price.Text = "0"; }

            txt_total.Text = "";
            txt_qty.Text = "";
        }

        private void txt_qty_TextChanged(object sender, EventArgs e)
        {
            if (txt_qty.Text.Length > 0)
            { txt_total.Text = (Convert.ToInt16(txt_price.Text) * Convert.ToInt16(txt_qty.Text)).ToString(); }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] arr = new string[4];
            arr[0] = cmb_items.SelectedItem.ToString();
            arr[1] = txt_price.Text;
            arr[2] = txt_qty.Text;
            arr[3] = txt_total.Text;

            ListViewItem lvi = new ListViewItem(arr);
            listView1.Items.Add(lvi);
            txt_sub.Text = (Convert.ToInt16(txt_sub.Text) + Convert.ToInt16(txt_total.Text)).ToString();
        }

        private void txt_dis_TextChanged(object sender, EventArgs e)
        {
            if(txt_dis.Text.Length>0)
            {
                txt_net.Text = (Convert.ToInt16(txt_sub.Text) - Convert.ToInt16(txt_dis.Text)).ToString();
            }
        }

        private void txt_paid_TextChanged(object sender, EventArgs e)
        {
            if (txt_paid.Text.Length > 0)
            {
                txt_balance.Text = (Convert.ToInt16(txt_paid.Text) - Convert.ToInt16(txt_net.Text)).ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count>0)
            {
                for(int i=0;i<listView1.Items.Count;i++)
                {
                    if(listView1.Items[i].Selected)
                    {
                        txt_sub.Text= (Convert.ToInt16(txt_sub.Text) - Convert.ToInt16(listView1.Items[i].SubItems[3].Text)).ToString();
                        listView1.Items[i].Remove();
                    }
                }
            }
        }
    }
}
