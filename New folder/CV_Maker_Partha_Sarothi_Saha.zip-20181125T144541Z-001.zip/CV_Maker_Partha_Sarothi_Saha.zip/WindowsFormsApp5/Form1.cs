﻿using System;
/*using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;*/
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label21_Click(object sender, EventArgs e)
        {

        }

        private void label22_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox33_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox24_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox25_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox14_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox22_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox15_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox27_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox28_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox29_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox30_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox31_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox32_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Document doc = new Document(iTextSharp.text.PageSize.LETTER, 99, 99, 99, 99);
            PdfWriter myPDF = PdfWriter.GetInstance(doc, new FileStream("A_Cover_letter" + ".pdf", FileMode.Create));
            Paragraph a = new Paragraph("                                     EAST WEST UNIVERSITY\n\n");
            Paragraph b = new Paragraph("                             Application for jion as a Lec. on CSE\n\n");
            Paragraph C = new Paragraph("                                   ONLINE CURRICULAM VIATE\n\n");
            Paragraph d = new Paragraph("PERSONAL DATA\n\n");
            Paragraph f = new Paragraph("Name : " + textBox1.Text.ToString());
            Paragraph g = new Paragraph("Address : " + textBox2.Text.ToString());
            Paragraph h = new Paragraph("Tel No. : " + textBox3.Text.ToString());
            Paragraph i = new Paragraph("Date of Birth : " + textBox4.Text.ToString());
            Paragraph j = new Paragraph("Nationality : " + textBox5.Text.ToString());
            Paragraph k = new Paragraph("Marital Status : " + textBox6.Text.ToString());
            Paragraph m = new Paragraph("Health : " + textBox7.Text.ToString());
            Paragraph z = new Paragraph("Blood Group : " + textBox33.Text.ToString()+"\n\n");
            Paragraph n = new Paragraph("EDUCATION QUALIFICATIONS\n\n");
            Paragraph O = new Paragraph("Degree : " + textBox8.Text.ToString() +  "     Institution : " + textBox9.Text.ToString() +  "    Result : " + textBox10.Text.ToString() + "     Year : " + textBox11.Text.ToString());
            Paragraph p = new Paragraph("Degree : " + textBox12.Text.ToString() + "     Institution : " + textBox13.Text.ToString() + "    Result : " + textBox14.Text.ToString() + "     Year : " + textBox15.Text.ToString());
            Paragraph q = new Paragraph("Degree : " + textBox16.Text.ToString() + "     Institution : " + textBox17.Text.ToString() + "    Result : " + textBox18.Text.ToString() + "     Year : " + textBox19.Text.ToString());
            Paragraph r = new Paragraph("Degree : " + textBox20.Text.ToString() + "     Institution : " + textBox21.Text.ToString() + "    Result : " + textBox22.Text.ToString() + "     Year : " + textBox23.Text.ToString());
            Paragraph s = new Paragraph("Degree : " + textBox24.Text.ToString() + "     Institution : " + textBox25.Text.ToString() + "    Result : " + textBox26.Text.ToString() + "     Year : " + textBox27.Text.ToString()+"\n\n");
            Paragraph t = new Paragraph("NON-ACADEMIC ACHEIVEMENTS\n\n");
            Paragraph u = new Paragraph("1) " + textBox28.Text.ToString());
            Paragraph v = new Paragraph("2) " + textBox29.Text.ToString());
            Paragraph w = new Paragraph("3) " + textBox30.Text.ToString());
            Paragraph x = new Paragraph("Experience : " + textBox31.Text.ToString());
            Paragraph y = new Paragraph("Language : " + textBox32.Text.ToString());
            doc.Open();
            doc.Add(a);
            doc.Add(b);
            doc.Add(C);
            doc.Add(d);
            doc.Add(f);
            doc.Add(g);
            doc.Add(h);
            doc.Add(i);
            doc.Add(j);
            doc.Add(k);
            doc.Add(m);
            doc.Add(z);
            doc.Add(n);
            doc.Add(O);
            doc.Add(p);
            doc.Add(q);
            doc.Add(r);
            doc.Add(s);
            doc.Add(t);
            doc.Add(u);
            doc.Add(v);
            doc.Add(w);
            doc.Add(x);
            doc.Add(y);
            doc.Close();
            MessageBox.Show("Saved");
        }
    }
}
