﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projcet_3
{
   public class Certificate
    {
        static void Main(string[] args)

{
	private string name;
	private string father_name;
	private string mother_name;
	private string id;
	private string subject;
	private float cgpa;
	public void set()
	{
		Console.Write("Enter your Name:");
		name = Console.ReadLine();
		Console.Write("Enter your Father's Name:");
		father_name = Console.ReadLine();
		Console.Write("Enter your Mother's Name:");
		mother_name = Console.ReadLine();
		Console.Write("Enter your ID Number:");
		id = Console.ReadLine();
		Console.Write("Enter your Subject:");
		subject = Console.ReadLine();
		Console.Write("Enter your CGPA:");
		cgpa = float.Parse(ConsoleInput.ReadToWhiteSpace(true));
		Console.Read();
	}
	public void display()
	{
		Console.Write("{0,8}", " *****   *   **** *****   *       * ***** **** *****   *   * *   * *** *   * ***** ***** **** *** ***** *   * ");
		Console.Write("{0}", "\n");
		Console.Write("{0,8}", " *      * *  *      *     *   *   * *     *      *     *   * **  *  *  *   * *     *   * *     *    *    * *  ");
		Console.Write("{0}", "\n");
		Console.Write("{0,8}", " ***** ***** ****   *      * * * *  ***** ****   *     *   * * * *  *  *   * ***** ***** ****  *    *     *   ");
		Console.Write("{0}", "\n");
		Console.Write("{0,8}", " *     *   *    *   *       ** **   *        *   *     *   * *  **  *   * *  *     *  *     *  *    *     *   ");
		Console.Write("{0}", "\n");
		Console.Write("{0,8}", " ***** *   * ****   *       ** **   ***** ****   *      ***  *   * ***   *   ***** *   * **** ***   *     *   ");
		Console.Write("{0}", "\n");
		Console.Write("{0,12}", "Department of Computer Science & Engineering ");
		Console.Write("{0}", "\n");
		Console.Write("{0}", "This is to Certified that ");
		Console.Write("{0}", name);
		Console.Write("{0}", " Son / Daughter of ");
		Console.Write("{0}", father_name);
		Console.Write("{0}", "\n");
		Console.Write("{0}", " and ");
		Console.Write("{0}", mother_name);
		Console.Write("{0}", " of East West University of Dhaka bearing ID No. ");
		Console.Write("{0}", id);
		Console.Write("{0}", "\n");
		Console.Write("{0}", " duly passed all the courses of ");
		Console.Write("{0}", subject);
		Console.Write("{0}", "required  and got CGPA : ");
		Console.Write("{0}", "\n");
		Console.Write("{0}", cgpa);
		Console.Write("{0}", " on the scale of 4.00");
		Console.Write("{0}", "\n");

	}
}

public static class GlobalMembers
{
	static int Main()
	{
		Certificate[] C = Arrays.InitializeWithDefaultInstances<Certificate>(1000);
		for (int i = 0; i < 1000 ; i++)
		{
			C[i].set();
			C[i].display();
			Console.Write("Do you want to continue press (Y/N)");
			char ch;
			ch = char.Parse(ConsoleInput.ReadToWhiteSpace(true));
			if (ch == 'N' || ch == 'n')
			{
				return 0;
			}
		}
	}
}
     }
    

